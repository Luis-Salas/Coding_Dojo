module BeltsHelper
end
