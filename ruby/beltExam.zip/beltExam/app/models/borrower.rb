class Borrower < ActiveRecord::Base
end
