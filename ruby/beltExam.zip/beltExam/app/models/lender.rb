class Lender < ActiveRecord::Base
end
